// Navigation toggle (mobile)
const navToggle = document.getElementById('navToggle');
const primaryNav = document.getElementById('primaryNav');
navToggle.addEventListener('click', () => {
  const expanded = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', String(!expanded));
  primaryNav.classList.toggle('show');
});

// Close menu on link click (mobile UX)
primaryNav.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => primaryNav.classList.remove('show'));
});

// Smooth scroll & active link highlight
const sections = document.querySelectorAll('section[id]');
const navLinks = Array.from(primaryNav.querySelectorAll('a')).filter(a => a.getAttribute('href').startsWith('#'));
const setActiveLink = () => {
  let current = null;
  const fromTop = window.scrollY + 100;
  sections.forEach(sec => {
    if (sec.offsetTop <= fromTop && (sec.offsetTop + sec.offsetHeight) > fromTop) {
      current = '#' + sec.id;
    }
  });
  navLinks.forEach(link => {
    if (link.getAttribute('href') === current) {
      link.style.background = 'rgba(255,255,255,.08)';
    } else {
      link.style.background = 'transparent';
    }
  });
};
window.addEventListener('scroll', setActiveLink);
setActiveLink();

// Contact form (demo-only, no backend)
const form = document.getElementById('contactForm');
const statusEl = document.getElementById('formStatus');
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const message = form.message.value.trim();

  if (!name || !email || !message) {
    statusEl.textContent = 'Please fill in all fields.';
    statusEl.style.color = '#ffb4ab';
    return;
  }

  // Basic email pattern
  const emailOK = /^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(email);
  if (!emailOK) {
    statusEl.textContent = 'Please enter a valid email address.';
    statusEl.style.color = '#ffb4ab';
    return;
  }

  // Fake submit
  setTimeout(() => {
    statusEl.textContent = 'Thanks! Your message has been queued (demo).';
    statusEl.style.color = '';
    form.reset();
  }, 300);
});

// Footer year
document.getElementById('year').textContent = new Date().getFullYear();
